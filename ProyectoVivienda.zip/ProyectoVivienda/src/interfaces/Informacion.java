package interfaces;

import tipos.TpEPO;

public interface Informacion {
	
	public TpEPO getEpoca();
	
	public void setEpoca(TpEPO tipoEPO);


}
