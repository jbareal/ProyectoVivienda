package tipos;

public enum TpEPO {
	VERANO, INVIERNO, ANUAL

}
