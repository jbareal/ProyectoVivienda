package tipos;

public enum TpPAGO {
        TARJETA, PAYPAL, EFECTIVO, TODO;
	
}
