package tipos;

public enum TpCAS {
	ADOSADO, PAREADO, PISO

}
